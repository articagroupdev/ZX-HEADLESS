globalThis.__BUILD_MANIFEST = {
  "pages": {
    "/_app": []
  },
  "devFiles": [],
  "polyfillFiles": [
    "static/chunks/a6dad97d9634a72d.js"
  ],
  "lowPriorityFiles": [],
  "rootMainFiles": [
    "static/chunks/1c7169261bc4f2b5.js",
    "static/chunks/82abf2d65f5428ae.js",
    "static/chunks/aee6c7720838f8a2.js",
    "static/chunks/d702a24e2b6c48fa.js",
    "static/chunks/turbopack-b19bc4d5b8d41157.js"
  ]
};
globalThis.__BUILD_MANIFEST.lowPriorityFiles = [
"/static/" + process.env.__NEXT_BUILD_ID + "/_buildManifest.js",
"/static/" + process.env.__NEXT_BUILD_ID + "/_ssgManifest.js"
];