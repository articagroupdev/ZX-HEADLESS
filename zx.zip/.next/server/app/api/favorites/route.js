var R=require("../../../chunks/[turbopack]_runtime.js")("server/app/api/favorites/route.js")
R.c("server/chunks/[root-of-the-server]__c2825221._.js")
R.c("server/chunks/node_modules_next_f5199d09._.js")
R.c("server/chunks/node_modules_next_dist_3cae5f3a._.js")
R.c("server/chunks/[root-of-the-server]__8f5ebbc3._.js")
R.c("server/chunks/_next-internal_server_app_api_favorites_route_actions_62ed14de.js")
R.m(43636)
module.exports=R.m(43636).exports
