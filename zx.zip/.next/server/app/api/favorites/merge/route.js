var R=require("../../../../chunks/[turbopack]_runtime.js")("server/app/api/favorites/merge/route.js")
R.c("server/chunks/[root-of-the-server]__f2448b46._.js")
R.c("server/chunks/node_modules_next_f5199d09._.js")
R.c("server/chunks/node_modules_next_dist_3cae5f3a._.js")
R.c("server/chunks/[root-of-the-server]__8f5ebbc3._.js")
R.c("server/chunks/_next-internal_server_app_api_favorites_merge_route_actions_b273085e.js")
R.m(31654)
module.exports=R.m(31654).exports
