var R=require("../../../../chunks/[turbopack]_runtime.js")("server/app/api/account/me/route.js")
R.c("server/chunks/[root-of-the-server]__8a345dfb._.js")
R.c("server/chunks/node_modules_next_f5199d09._.js")
R.c("server/chunks/node_modules_next_dist_3cae5f3a._.js")
R.c("server/chunks/[root-of-the-server]__8f5ebbc3._.js")
R.c("server/chunks/_next-internal_server_app_api_account_me_route_actions_ec8c78cf.js")
R.m(11784)
module.exports=R.m(11784).exports
