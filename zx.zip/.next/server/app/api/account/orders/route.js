var R=require("../../../../chunks/[turbopack]_runtime.js")("server/app/api/account/orders/route.js")
R.c("server/chunks/[root-of-the-server]__61943c7d._.js")
R.c("server/chunks/node_modules_next_f5199d09._.js")
R.c("server/chunks/node_modules_next_dist_3cae5f3a._.js")
R.c("server/chunks/[root-of-the-server]__8f5ebbc3._.js")
R.c("server/chunks/_next-internal_server_app_api_account_orders_route_actions_f5ea199a.js")
R.m(7064)
module.exports=R.m(7064).exports
