var R=require("../../../../../chunks/[turbopack]_runtime.js")("server/app/api/store/cart/add/route.js")
R.c("server/chunks/[root-of-the-server]__3df2ad85._.js")
R.c("server/chunks/node_modules_next_dist_3cae5f3a._.js")
R.c("server/chunks/node_modules_next_f2da0d3e._.js")
R.c("server/chunks/[root-of-the-server]__8f5ebbc3._.js")
R.c("server/chunks/_next-internal_server_app_api_store_cart_add_route_actions_984cd1ef.js")
R.m(71067)
module.exports=R.m(71067).exports
