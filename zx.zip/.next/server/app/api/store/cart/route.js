var R=require("../../../../chunks/[turbopack]_runtime.js")("server/app/api/store/cart/route.js")
R.c("server/chunks/[root-of-the-server]__fd4b9421._.js")
R.c("server/chunks/node_modules_next_dist_3cae5f3a._.js")
R.c("server/chunks/node_modules_next_f2da0d3e._.js")
R.c("server/chunks/[root-of-the-server]__8f5ebbc3._.js")
R.c("server/chunks/_next-internal_server_app_api_store_cart_route_actions_17d84e28.js")
R.m(20321)
module.exports=R.m(20321).exports
