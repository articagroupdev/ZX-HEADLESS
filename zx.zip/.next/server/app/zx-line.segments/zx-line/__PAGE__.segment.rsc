1:"$Sreact.fragment"
2:I[53136,["/_next/static/chunks/986d3ba6cd91f02e.js","/_next/static/chunks/0e1747e834b56ef7.js","/_next/static/chunks/80195c919c2ee5b6.js","/_next/static/chunks/b55491d4d000d818.js","/_next/static/chunks/ef7b4131b71dee95.js"],"AboutUsContent"]
3:I[97367,["/_next/static/chunks/ff1a16fafef87110.js","/_next/static/chunks/d2be314c3ece3fbe.js"],"OutletBoundary"]
4:"$Sreact.suspense"
0:{"buildId":"F14T-drKSYPzgN-QfemcU","rsc":["$","$1","c",{"children":[["$","div",null,{"className":"min-h-screen bg-white text-neutral-900","children":["$","$L2",null,{}]}],[["$","script","script-0",{"src":"/_next/static/chunks/ef7b4131b71dee95.js","async":true}]],["$","$L3",null,{"children":["$","$4",null,{"name":"Next.MetadataOutlet","children":"$@5"}]}]]}],"loading":null,"isPartial":false}
5:null
