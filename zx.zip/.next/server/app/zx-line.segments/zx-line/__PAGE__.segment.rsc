1:"$Sreact.fragment"
2:I[53136,["/_next/static/chunks/986d3ba6cd91f02e.js","/_next/static/chunks/0e1747e834b56ef7.js","/_next/static/chunks/4d0a71e365b2c14d.js","/_next/static/chunks/b55491d4d000d818.js","/_next/static/chunks/65062e60dc7c61c3.js"],"AboutUsContent"]
3:I[97367,["/_next/static/chunks/ff1a16fafef87110.js","/_next/static/chunks/d2be314c3ece3fbe.js"],"OutletBoundary"]
4:"$Sreact.suspense"
0:{"buildId":"Yt24Osk5637lxhT34vWPz","rsc":["$","$1","c",{"children":[["$","div",null,{"className":"min-h-screen bg-white text-neutral-900","children":["$","$L2",null,{}]}],[["$","script","script-0",{"src":"/_next/static/chunks/65062e60dc7c61c3.js","async":true}]],["$","$L3",null,{"children":["$","$4",null,{"name":"Next.MetadataOutlet","children":"$@5"}]}]]}],"loading":null,"isPartial":false}
5:null
