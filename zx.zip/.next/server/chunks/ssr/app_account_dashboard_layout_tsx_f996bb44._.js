module.exports=[76191,a=>{"use strict";var b=a.i(7997);function c({children:a}){return(0,b.jsx)(b.Fragment,{children:a})}a.s(["default",()=>c,"metadata",0,{title:"Mi cuenta",description:"Tu perfil, pedidos y direcciones"}])}];

//# sourceMappingURL=app_account_dashboard_layout_tsx_f996bb44._.js.map