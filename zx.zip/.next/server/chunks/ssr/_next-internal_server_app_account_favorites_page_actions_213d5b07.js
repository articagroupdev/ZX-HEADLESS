module.exports=[17999,(a,b,c)=>{}];

//# sourceMappingURL=_next-internal_server_app_account_favorites_page_actions_213d5b07.js.map