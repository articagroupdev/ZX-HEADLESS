module.exports=[63881,(a,b,c)=>{}];

//# sourceMappingURL=_next-internal_server_app_account_system_page_actions_4f438353.js.map